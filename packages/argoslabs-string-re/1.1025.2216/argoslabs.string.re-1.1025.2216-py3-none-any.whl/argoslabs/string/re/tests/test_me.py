#!/usr/bin/env python
# coding=utf8
"""
====================================
 :mod:`argoslabs.string.re`
====================================
.. moduleauthor:: Jerry Chae <mcchae@argos-labs.com>
.. note:: ARGOS-LABS License

Description
===========
ARGOS LABS plugin module : unittest
"""

################################################################################
import os
import sys
# from alabs.common.util.vvargs import ArgsError
from unittest import TestCase
# noinspection PyProtectedMember
from argoslabs.string.re import _main as main
from contextlib import contextmanager
from io import StringIO
from tempfile import gettempdir

################################################################################
@contextmanager
def captured_output():
    new_out, new_err = StringIO(), StringIO()
    old_out, old_err = sys.stdout, sys.stderr
    try:
        sys.stdout, sys.stderr = new_out, new_err
        yield sys.stdout, sys.stderr
    finally:
        sys.stdout, sys.stderr = old_out, old_err


################################################################################
class TU(TestCase):
    """
    TestCase for argoslabs.demo.helloworld
    """
    # ==========================================================================
    isFirst = True
    file = os.path.join(gettempdir(), 'argoslabs.string.re.file.txt')

    # ==========================================================================
    def test0000_init(self):
        if os.path.exists(TU.file):
            os.remove(TU.file)
        with open(TU.file, 'w') as ofp:
            ofp.write('''hello tom and jerry
hello Tom tom and jerry Jerry
hello,|Tom , tom|and    jerry\tJerry
''')
        self.assertTrue(os.path.exists(TU.file))

    # ==========================================================================
    def test0100_invalid_operator(self):
        stderr = None
        try:
            _ = main('unknown', 'tom', 'jerry')
            self.assertTrue(False)
        except Exception as e:
            sys.stderr.write('%s\n' % str(e))
            self.assertTrue(True)

    # ==========================================================================
    def test0110_find(self):
        stderr = None
        try:
            with captured_output() as (out, err):
                r = main('find', r'\w+', 'hello tom and jerry')
            self.assertTrue(r == 0)
            stdout = out.getvalue().strip()
            if stdout:
                print(stdout)
            stderr = err.getvalue().strip()
            if stderr:
                sys.stderr.write('%s%s' % (stderr, os.linesep))
            self.assertTrue(len(stdout.split('\n')) == 4)
        except Exception as e:
            sys.stderr.write('%s\n' % str(e))
            if stderr:
                sys.stderr.write(stderr)
            self.assertTrue(False)

    # ==========================================================================
    def test0115_find_length(self):
        stderr = None
        try:
            with captured_output() as (out, err):
                r = main('find', r'\w+', 'hello tom and jerry',
                         '--length')
            self.assertTrue(r == 0)
            stdout = out.getvalue().strip()
            self.assertTrue(stdout == '4')
        except Exception as e:
            sys.stderr.write('%s\n' % str(e))
            if stderr:
                sys.stderr.write(stderr)
            self.assertTrue(False)

    # ==========================================================================
    def test0120_find_limit(self):
        stderr = None
        try:
            with captured_output() as (out, err):
                r = main('find', r'\w+', 'hello tom and jerry', '--limit', '3')
            self.assertTrue(r == 0)
            stdout = out.getvalue().strip()
            if stdout:
                print(stdout)
            stderr = err.getvalue().strip()
            if stderr:
                sys.stderr.write('%s%s' % (stderr, os.linesep))
            self.assertTrue(len(stdout.split('\n')) == 3)
        except Exception as e:
            sys.stderr.write('%s\n' % str(e))
            if stderr:
                sys.stderr.write(stderr)
            self.assertTrue(False)

    # ==========================================================================
    def test0130_find_with_or(self):
        stderr = None
        try:
            with captured_output() as (out, err):
                r = main('find', r'(tom|jerry)', 'hello Tom tom and jerry Jerry')
            self.assertTrue(r == 0)
            stdout = out.getvalue().strip()
            if stdout:
                print(stdout)
            stderr = err.getvalue().strip()
            if stderr:
                sys.stderr.write('%s%s' % (stderr, os.linesep))
            self.assertTrue(len(stdout.split('\n')) == 2)
        except Exception as e:
            sys.stderr.write('%s\n' % str(e))
            if stderr:
                sys.stderr.write(stderr)
            self.assertTrue(False)

    # ==========================================================================
    def test0140_find_with_or_ignorecase(self):
        stderr = None
        try:
            with captured_output() as (out, err):
                r = main('find', r'(tom|jerry)', 'hello Tom tom and jerry Jerry',
                         '--ignore-case')
            self.assertTrue(r == 0)
            stdout = out.getvalue().strip()
            if stdout:
                print(stdout)
            stderr = err.getvalue().strip()
            if stderr:
                sys.stderr.write('%s%s' % (stderr, os.linesep))
            self.assertTrue(len(stdout.split('\n')) == 4)
        except Exception as e:
            sys.stderr.write('%s\n' % str(e))
            if stderr:
                sys.stderr.write(stderr)
            self.assertTrue(False)

    # ==========================================================================
    def test0150_split(self):
        stderr = None
        try:
            with captured_output() as (out, err):
                r = main('split', r'[\s,|]+', 'hello,|Tom , tom|and    jerry\tJerry')
            self.assertTrue(r == 0)
            stdout = out.getvalue().strip()
            if stdout:
                print(stdout)
            stderr = err.getvalue().strip()
            if stderr:
                sys.stderr.write('%s%s' % (stderr, os.linesep))
            self.assertTrue(len(stdout.split('\n')) == 6)
        except Exception as e:
            sys.stderr.write('%s\n' % str(e))
            if stderr:
                sys.stderr.write(stderr)
            self.assertTrue(False)

    # ==========================================================================
    def test0155_split_length(self):
        stderr = None
        try:
            with captured_output() as (out, err):
                r = main('split', r'[\s,|]+', 'hello,|Tom , tom|and    jerry\tJerry',
                         '--length')
            self.assertTrue(r == 0)
            stdout = out.getvalue().strip()
            self.assertTrue(stdout == '6')
        except Exception as e:
            sys.stderr.write('%s\n' % str(e))
            if stderr:
                sys.stderr.write(stderr)
            self.assertTrue(False)

    # ==========================================================================
    def test0160_split_with_limit(self):
        stderr = None
        try:
            with captured_output() as (out, err):
                r = main('split', r'[\s,|]+', 'hello,|Tom , tom|and    jerry\tJerry',
                         '--limit', '3')
            self.assertTrue(r == 0)
            stdout = out.getvalue().strip()
            if stdout:
                print(stdout)
            stderr = err.getvalue().strip()
            if stderr:
                sys.stderr.write('%s%s' % (stderr, os.linesep))
            self.assertTrue(len(stdout.split('\n')) == 3)
        except Exception as e:
            sys.stderr.write('%s\n' % str(e))
            if stderr:
                sys.stderr.write(stderr)
            self.assertTrue(False)

    # ==========================================================================
    def test0170_replace(self):
        stderr = None
        try:
            with captured_output() as (out, err):
                r = main('replace', r'[\s,|]+', 'hello,|Tom , tom|and    jerry\tJerry',
                         '--replace', ',')
            self.assertTrue(r == 0)
            stdout = out.getvalue().strip()
            if stdout:
                print(stdout)
            stderr = err.getvalue().strip()
            if stderr:
                sys.stderr.write('%s%s' % (stderr, os.linesep))
            self.assertTrue(stdout == 'hello,Tom,tom,and,jerry,Jerry')
        except Exception as e:
            sys.stderr.write('%s\n' % str(e))
            if stderr:
                sys.stderr.write(stderr)
            self.assertTrue(False)

    # ==========================================================================
    def test0180_replace_limit(self):
        stderr = None
        try:
            with captured_output() as (out, err):
                r = main('replace', r'[\s,|]+', 'hello,|Tom , tom|and    jerry\tJerry',
                         '--replace', ',', '--limit', '4')
            self.assertTrue(r == 0)
            stdout = out.getvalue().strip()
            if stdout:
                print(stdout)
            stderr = err.getvalue().strip()
            if stderr:
                sys.stderr.write('%s%s' % (stderr, os.linesep))
            self.assertTrue(stdout == 'hello,Tom,tom,and,jerry\tJerry')
        except Exception as e:
            sys.stderr.write('%s\n' % str(e))
            if stderr:
                sys.stderr.write(stderr)
            self.assertTrue(False)

    # ==========================================================================
    def test0190_replace_limit_without_replace(self):
        stderr = None
        try:
            with captured_output() as (out, err):
                r = main('replace', r'[\s,|]+', 'hello,|Tom , tom|and    jerry\tJerry',
                         '--limit', '4')
            self.assertTrue(r == 0)
            stdout = out.getvalue().strip()
            if stdout:
                print(stdout)
            stderr = err.getvalue().strip()
            if stderr:
                sys.stderr.write('%s%s' % (stderr, os.linesep))
            self.assertTrue(stdout == 'helloTomtomandjerry\tJerry')
        except Exception as e:
            sys.stderr.write('%s\n' % str(e))
            if stderr:
                sys.stderr.write(stderr)
            self.assertTrue(False)

    # ==========================================================================
    def test0195_replace(self):
        stderr = None
        try:
            with captured_output() as (out, err):
                r = main('replace', r',', 'a@b.c.d,b@c.d.e', '--replace', ', ')
            self.assertTrue(r == 0)
            stdout = out.getvalue().strip()
            if stdout:
                print(stdout)
            stderr = err.getvalue().strip()
            if stderr:
                sys.stderr.write('%s%s' % (stderr, os.linesep))
            self.assertTrue(stdout == 'a@b.c.d, b@c.d.e')
        except Exception as e:
            sys.stderr.write('%s\n' % str(e))
            if stderr:
                sys.stderr.write(stderr)
            self.assertTrue(False)

    # ==========================================================================
    def test0200_find_from_file(self):
        stderr = None
        try:
            with captured_output() as (out, err):
                r = main('find', r'\w+', '--file', TU.file)
            self.assertTrue(r == 0)
            stdout = out.getvalue().strip()
            if stdout:
                print(stdout)
            stderr = err.getvalue().strip()
            if stderr:
                sys.stderr.write('%s%s' % (stderr, os.linesep))
            self.assertTrue(len(stdout.split('\n')) == 16)
        except Exception as e:
            sys.stderr.write('%s\n' % str(e))
            if stderr:
                sys.stderr.write(stderr)
            self.assertTrue(False)

    # ==========================================================================
    def test0210_find_from_file_limit(self):
        stderr = None
        try:
            with captured_output() as (out, err):
                r = main('find', r'\w+', '--file', TU.file, '--limit', 10)
            self.assertTrue(r == 0)
            stdout = out.getvalue().strip()
            if stdout:
                print(stdout)
            stderr = err.getvalue().strip()
            if stderr:
                sys.stderr.write('%s%s' % (stderr, os.linesep))
            self.assertTrue(len(stdout.split('\n')) == 10)
        except Exception as e:
            sys.stderr.write('%s\n' % str(e))
            if stderr:
                sys.stderr.write(stderr)
            self.assertTrue(False)

    # ==========================================================================
    def test0220_replace_from_file(self):
        stderr = None
        try:
            with captured_output() as (out, err):
                r = main('replace', r'tom', '--file', TU.file,
                         '--replace', 'foo',
                         '--ignore-case')
            self.assertTrue(r == 0)
            stdout = out.getvalue().strip()
            if stdout:
                print(stdout)
            stderr = err.getvalue().strip()
            if stderr:
                sys.stderr.write('%s%s' % (stderr, os.linesep))
            self.assertTrue(stdout == 'hello foo and jerry\nhello foo foo and jerry Jerry\nhello,|foo , foo|and    jerry	Jerry')
        except Exception as e:
            sys.stderr.write('%s\n' % str(e))
            if stderr:
                sys.stderr.write(stderr)
            self.assertTrue(False)

    # ==========================================================================
    def test0230_replace_from_file_limit(self):
        stderr = None
        try:
            with captured_output() as (out, err):
                r = main('replace', r'tom', '--file', TU.file,
                         '--replace', 'foo',
                         '--ignore-case', '--limit', 4)
            self.assertTrue(r == 0)
            stdout = out.getvalue().strip()
            if stdout:
                print(stdout)
            stderr = err.getvalue().strip()
            if stderr:
                sys.stderr.write('%s%s' % (stderr, os.linesep))
            self.assertTrue(stdout == 'hello foo and jerry\nhello foo foo and jerry Jerry\nhello,|foo , tom|and    jerry	Jerry')
        except Exception as e:
            sys.stderr.write('%s\n' % str(e))
            if stderr:
                sys.stderr.write(stderr)
            self.assertTrue(False)

    # ==========================================================================
    def test0240_split_with_file(self):
        stderr = None
        try:
            with captured_output() as (out, err):
                r = main('split', r'[\s,|]+', '--file', TU.file)
            self.assertTrue(r == 0)
            stdout = out.getvalue().strip()
            if stdout:
                print(stdout)
            stderr = err.getvalue().strip()
            if stderr:
                sys.stderr.write('%s%s' % (stderr, os.linesep))
            self.assertTrue(len(stdout.split('\n')) == 16)
        except Exception as e:
            sys.stderr.write('%s\n' % str(e))
            if stderr:
                sys.stderr.write(stderr)
            self.assertTrue(False)

    # ==========================================================================
    def test0250_split_with_file_limit(self):
        stderr = None
        try:
            with captured_output() as (out, err):
                r = main('split', r'[\s,|]+', '--file', TU.file, '--limit', 13)
            self.assertTrue(r == 0)
            stdout = out.getvalue().strip()
            if stdout:
                print(stdout)
            stderr = err.getvalue().strip()
            if stderr:
                sys.stderr.write('%s%s' % (stderr, os.linesep))
            self.assertTrue(len(stdout.split('\n')) == 13)
        except Exception as e:
            sys.stderr.write('%s\n' % str(e))
            if stderr:
                sys.stderr.write(stderr)
            self.assertTrue(False)

    # ==========================================================================
    def test0260_find_with_ignorecase(self):
        stderr = None
        try:
            with captured_output() as (out, err):
                r = main('find', 'hel', 'hello, Hello world hello Hello Hel',)
            self.assertTrue(r == 0)
            stdout = out.getvalue().strip()
            print('%s' % '='*80)
            if stdout:
                print(stdout)
            stderr = err.getvalue().strip()
            if stderr:
                sys.stderr.write('%s%s' % (stderr, os.linesep))
            self.assertTrue(len(stdout.split('\n')) == 2)

            with captured_output() as (out, err):
                r = main('find', 'hel', 'hello, Hello world hello Hello Hel',
                         '--ignore-case')
            self.assertTrue(r == 0)
            stdout = out.getvalue().strip()
            print('%s' % '='*80)
            if stdout:
                print(stdout)
            stderr = err.getvalue().strip()
            if stderr:
                sys.stderr.write('%s%s' % (stderr, os.linesep))
            self.assertTrue(len(stdout.split('\n')) == 5)

        except Exception as e:
            sys.stderr.write('%s\n' % str(e))
            if stderr:
                sys.stderr.write(stderr)
            self.assertTrue(False)

    # ==========================================================================
    def test0270_tolower(self):
        stderr = None
        try:
            with captured_output() as (out, err):
                r = main('tolower', '', 'Hi Hello World?',)
            self.assertTrue(r == 0)
            stdout = out.getvalue().strip()
            if stdout:
                print(stdout)
            self.assertTrue(stdout == 'hi hello world?')

            with captured_output() as (out, err):
                r = main('toupper', '', 'Hi Hello World?',)
            self.assertTrue(r == 0)
            stdout = out.getvalue().strip()
            if stdout:
                print(stdout)
            self.assertTrue(stdout == 'HI HELLO WORLD?')

        except Exception as e:
            sys.stderr.write('%s\n' % str(e))
            if stderr:
                sys.stderr.write(stderr)
            self.assertTrue(False)

    # ==========================================================================
    def test0280_substring(self):
        stderr = None
        try:
            with captured_output() as (out, err):
                r = main('substring', 'Hello', 'Hi Hello World?',)
            self.assertTrue(r == 0)
            stdout = out.getvalue().strip()
            if stdout:
                print(stdout)
            self.assertTrue(stdout == '3')

            with captured_output() as (out, err):
                r = main('substring', 'hello', 'Hi Hello World?',)
            self.assertTrue(r == 0)
            stdout = out.getvalue().strip()
            if stdout:
                print(stdout)
            self.assertTrue(stdout == '-1')

            with captured_output() as (out, err):
                r = main('substring', 'hello', 'Hi Hello World?', '--ignore-case')
            self.assertTrue(r == 0)
            stdout = out.getvalue().strip()
            if stdout:
                print(stdout)
            self.assertTrue(stdout == '3')
        except Exception as e:
            sys.stderr.write('%s\n' % str(e))
            if stderr:
                sys.stderr.write(stderr)
            self.assertTrue(False)

    # ==========================================================================
    def test0290_replace_twobyte_character_01(self):
        stderr = None
        mbstr = 'おはようございます。本日は晴天なり。　ここにダブルバイトが入っています。「　」。'
        try:
            with captured_output() as (out, err):
                r = main('replace', r'[\s]', mbstr,
                         '--replace', ' ')
            self.assertTrue(r == 0)
            stdout = out.getvalue().strip()
            if stdout:
                print(stdout)
            print(len(mbstr.encode('utf-8')))
            print(len(stdout.encode('utf-8')))
            self.assertTrue(len(mbstr.encode('utf-8')) == len(stdout.encode('utf-8'))+4)
            sbstr = stdout

            with captured_output() as (out, err):
                r = main('replace', r'　', mbstr,
                         '--replace', ' ')
            self.assertTrue(r == 0)
            stdout = out.getvalue().strip()
            if stdout:
                print(stdout)
            print(len(mbstr.encode('utf-8')))
            print(len(stdout.encode('utf-8')))
            self.assertTrue(len(mbstr.encode('utf-8')) == len(stdout.encode('utf-8'))+4)

            with captured_output() as (out, err):
                r = main('replace', r'[ ]', sbstr,
                         '--replace', '　')
            self.assertTrue(r == 0)
            stdout = out.getvalue().strip()
            if stdout:
                print(stdout)
            print(len(sbstr.encode('utf-8')))
            print(len(stdout.encode('utf-8')))
            self.assertTrue(len(sbstr.encode('utf-8'))+4 == len(stdout.encode('utf-8')))
        except Exception as e:
            sys.stderr.write('%s\n' % str(e))
            if stderr:
                sys.stderr.write(stderr)
            self.assertTrue(False)

    # ==========================================================================
    def test0300_replace_twobyte_character_01(self):
        stderr = None
        mbstr = 'おはようございます。本日は晴天なり。　ここにダブルバイトが入っています。「　」。'
        try:
            with captured_output() as (out, err):
                r = main('replace', r'。', mbstr,
                         '--replace', '.')
            self.assertTrue(r == 0)
            stdout = out.getvalue().strip()
            if stdout:
                print(stdout)
            print(len(mbstr.encode('utf-8')))
            print(len(stdout.encode('utf-8')))
            self.assertTrue(len(mbstr.encode('utf-8')) == len(stdout.encode('utf-8'))+8)
            sbstr = stdout

            with captured_output() as (out, err):
                r = main('replace', r'[.]', sbstr,
                         '--replace', '。')
            self.assertTrue(r == 0)
            stdout = out.getvalue().strip()
            if stdout:
                print(stdout)
            print(len(sbstr.encode('utf-8')))
            print(len(stdout.encode('utf-8')))
            self.assertTrue(len(sbstr.encode('utf-8'))+8 == len(stdout.encode('utf-8')))
        except Exception as e:
            sys.stderr.write('%s\n' % str(e))
            if stderr:
                sys.stderr.write(stderr)
            self.assertTrue(False)

    # ==========================================================================
    def test0310_replace_from_file(self):
        os.chdir(os.path.dirname(__file__))
        stderr = None
        stdout = 'stdout.txt'
        try:
            r = main('replace', r',__LINECHANGE__,', '--file', 'name.txt',
                     '--replace', '\n',
                     '--outfile', stdout)
            self.assertTrue(r == 0)
            with open('name.txt', encoding='utf-8') as ifp:
                in_s = ifp.read()
            with open(stdout, encoding='utf-8') as ifp:
                out_s = ifp.read()
            self.assertTrue(in_s.replace(r',__LINECHANGE__,', '\n') == out_s)
        except Exception as e:
            sys.stderr.write('%s\n' % str(e))
            if stderr:
                sys.stderr.write(stderr)
            self.assertTrue(False)

    # ==========================================================================
    def test9999_quit(self):
        if os.path.exists(TU.file):
            os.remove(TU.file)
        self.assertTrue(not os.path.exists(TU.file))
